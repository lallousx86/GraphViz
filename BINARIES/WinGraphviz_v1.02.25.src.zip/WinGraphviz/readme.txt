                   ********************************************
                                  WinGraphviz 1.02.25

                   (c) Copyright oodTsen-WorkingHouse(Taiwan)
                   ********************************************

Thank you for using WinGraphviz 1.02.25

Graphvizis a Project of AT&T Labs research.It provides a collection of tools for manipulating graph structures and generating graph layouts.

WinGraphviz is a free software base on Graphviz project .It can  rander the dot-language to common Image-format.
and It's a Windows COM Object,and you can use it in your Windows-application or ASP service without a Unix server.

More information on the web site:
http://home.so-net.net.tw/oodtsen/wingraphviz

=============================
WHAT'S NEW IN WinGraphviz
=============================

* Fix up ToDot() error message.

=============================
Support image format
=============================
 TextImage
 -SVG	: Scalable Vector Graphics 
 -Plain	: Simple, line-based ASCII format.
 -PlainExt : Simple, line-based ASCII format.  
 -Dot	: Attributed DOT.  
 -Canon	: Prettyprint input; no layout is done. 
 -PS	: PostScript (EPSF) .  
 
 BinaryImage
 -GIF	: GIF. 
 -PNG	: Portable Network Graphics. 
 -SVGZ	: compressed SVG. 
 -WBMP	: Wireless BitMap (WBMP) format.
 -JPEG	: JPEG. 
 -EMF	: Enhanced-Format Metafiles
 
ImageMap
 -CMAP	: client-side image map 
 -IMAP	: image map 
 -ISMAP	: server-side image map 


