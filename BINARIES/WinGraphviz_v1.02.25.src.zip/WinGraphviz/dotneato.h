/****************************************************************************
 
    PROGRAM: dotneato.h
 
    PURPOSE: addtion code for graphviz 1.8.10
 
    FUNCTIONS:
 
        dotneato_initialize2() - 
		dotneato_terminate2() - 
		DOTNEATOCheck() - 
		DOTRander() - 
		NEATORander() -
        
    COMMENTS:
        
 
****************************************************************************/
#ifndef		DOTNEATO_H
#define		DOTNEATO_H

#define DOT_INFO_PROGRAM_NAME		"WinGraphviz"
#define DOT_INFO_PROGRAM_VERSION	"ver1.02.26, Jan,20/2005"
#define DOT_INFO_PROGRAM_BUILDDATE	"Jan ,20/2005"



#endif /* DOTNEATO_H */
