//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinGraphviz.rc
//
#define IDS_PROJNAME                    100
#define IDR_DOT                         101
#define IDR_NEATO                       102
#define IDR_BINARYIMAGE                 103
#define IDR_TWOPI                       104

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
