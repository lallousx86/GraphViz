/* This defeats the <malloc.h> that yacc generated code includes */
