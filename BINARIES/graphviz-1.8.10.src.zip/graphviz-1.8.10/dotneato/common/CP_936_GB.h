#define CP_936_DEFAULTFONT "����"

char * get_fontname_CP_936(char *font);

char * get_fontfam_CP_936(char *font);

int get_fontindex_CP_936(char *font);
